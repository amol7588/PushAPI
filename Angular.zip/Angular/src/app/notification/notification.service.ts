import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
url:string='https://localhost:5001/api/'

//pushSubscriptionModel = <PushNotifiationsSubscriptionModel>{};

constructor(private httpClient: HttpClient) { }
httpOptions: any

getNotification(): Observable<any> {
  return this.httpClient.get(this.url + 'push');
}

sendNotification(): Observable<any> {
  this.httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    observe: 'events'
  };

  return this.httpClient.get(this.url + 'publickey');
}

postDataToServer(subscription: PushSubscription, loginModel: number): Observable<any> {
  
  this.httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    observe: 'events'
  };

  return this.httpClient.post(this.url + 'push', subscription, this.httpOptions)
}


sendPushNotificationsServer(subscription: PushSubscription): Observable<any> {
  console.log('started send push notifications');
  console.log('Push Subscription::' + subscription);
  console.log('Push Subscription endpoint' + subscription.endpoint);
  
  
  
console.log(this.url+'push')

  return this.httpClient.get(this.url + 'push')
}


getPublicKey(): Observable<any> {
  return this.httpClient.get(this.url + 'publickey')
}
}
