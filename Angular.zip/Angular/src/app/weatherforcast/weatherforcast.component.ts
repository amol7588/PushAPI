import { Component, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NotificationService } from '../notification/notification.service';

@Component({
  selector: 'app-weather-forecast',
  templateUrl: './weatherforcast.component.html'
})
export class WeatherForecastComponent implements OnInit  {
  
  public forecasts: WeatherForecast[];
  baseUrl: string='http://localhost:44304/'
  constructor(private notification:NotificationService)  {
    
}

ngOnInit()  {
  console.log(this.baseUrl)
//  this.notification.getForcaste().subscribe(result => {
//     this.forecasts = result;
//     console.log(this.forecasts)
//   }, error => console.error(error));

  
}
}
interface WeatherForecast {
  dateFormatted: string;
  temperatureC: number;
  temperatureF: number;
  summary: string;
}
