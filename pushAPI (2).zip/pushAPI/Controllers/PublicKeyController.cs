﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace pushAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PublicKeyController : ControllerBase
    {
        private readonly PushNotificationsOptions _options;

        public PublicKeyController(IOptions<PushNotificationsOptions> options)
        {
            _options = options.Value;
        }

        public PushNotificationsOptions Get()
        {

            PushNotificationsOptions pushNotifications = new PushNotificationsOptions { PublicKey = _options.PublicKey, PrivateKey = _options.PrivateKey };
            return pushNotifications;
        }
    }

}