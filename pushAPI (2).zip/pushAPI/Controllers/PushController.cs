﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Lib.Net.Http.WebPush;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using pushAPI.Model;

namespace pushAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PushController : ControllerBase
    {
        SqlPushSubscription pushSubscription;
        WeatherNotificationsProducer weatherNotificationsProducer;
        public PushController(SqlPushSubscription _pushSubscription, WeatherNotificationsProducer _WeatherNotificationsProducer)
        {
            pushSubscription = _pushSubscription;
            weatherNotificationsProducer = _WeatherNotificationsProducer;
        }
       

        
        [HttpPost]
        public void Post([FromBody] Lib.Net.Http.WebPush.PushSubscription subscription)
        {

            Subscription subscription1 = new Subscription();
            subscription1.Token = subscription.Endpoint;
            subscription1.UserId = 123;
            string p = null;
            subscription.Keys.TryGetValue("p256dh", out p);
            string a = null;
            subscription.Keys.TryGetValue("auth", out a);
            subscription1.PublicKey = p;
            subscription1.PrivateKey = a;
            subscription1.IsSubscribed = true;
            pushSubscription.Insert(subscription1);
        }

        [HttpDelete("{endpoint}")]
        public void Delete(string endpoint)
        {
           // pushSubscription.Delete(endpoint);
        }

        [HttpGet]
        public void send()
        {
            
            weatherNotificationsProducer.SendNotifications(13);
        }


    }
}