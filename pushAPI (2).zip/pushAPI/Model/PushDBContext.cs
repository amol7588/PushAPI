﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace pushAPI.Model
{
    public partial class PushDBContext : DbContext
    {
        public PushDBContext()
        {
        }

        public PushDBContext(DbContextOptions<PushDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Subscription> Subscription { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=LAPTOP-3MHRHS4R\\SQLEXPRESS;DataBase=PushDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Subscription>(entity =>
            {
                entity.Property(e => e.SubscriptionId)
                    .HasColumnName("SubscriptionID")
                    .ValueGeneratedNever();

                entity.Property(e => e.PrivateKey).HasMaxLength(2500);

                entity.Property(e => e.PublicKey).HasMaxLength(2500);

                entity.Property(e => e.Token).IsRequired();
            });
        }
    }
}
