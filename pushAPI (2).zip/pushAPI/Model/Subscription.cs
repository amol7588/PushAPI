﻿using System;
using System.Collections.Generic;

namespace pushAPI.Model
{
    public partial class Subscription
    {
        public long SubscriptionId { get; set; }
        public string Token { get; set; }
        public int? UserId { get; set; }
        public bool? IsSubscribed { get; set; }
        public string PublicKey { get; set; }
        public string PrivateKey { get; set; }
    }
}
