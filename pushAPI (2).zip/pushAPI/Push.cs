﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pushAPI
{
    public class Pushclass
    {
        public int Id { get; set; }
        public string Message { get; set; }
    }
}
