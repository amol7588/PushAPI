﻿using pushAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pushAPI
{
    public class SqlPushSubscription
    {

        PushDBContext _pushDBContext = null;
        public SqlPushSubscription()
        {
            _pushDBContext = new PushDBContext();
        }

       public void Insert(Subscription subscription)
        {

            _pushDBContext.Subscription.Add(subscription);
            _pushDBContext.SaveChanges();

        }


        public IEnumerable<Subscription> get()
        {
           return _pushDBContext.Subscription.ToList();
        }
    }
}
