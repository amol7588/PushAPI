﻿using Lib.Net.Http.WebPush;
using Lib.Net.Http.WebPush.Authentication;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using pushAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace pushAPI
{
    public class WeatherNotificationsProducer
    {
        
        private readonly SqlPushSubscription _pushSubscriptionsService;
        private readonly PushServiceClient _pushClient;
        
        public WeatherNotificationsProducer(IOptions<PushNotificationsOptions> options, SqlPushSubscription pushSubscriptionsService, PushServiceClient pushClient)
        {
            _pushSubscriptionsService = pushSubscriptionsService;
            _pushClient = pushClient;
            _pushClient.DefaultAuthentication = new VapidAuthentication(options.Value.PublicKey, options.Value.PrivateKey)
            {
                Subject = "https://vaptapps.evalueserve.com/PIB/PIB_UI"
            };
        }

       
        public void SendNotifications(int temperatureC)

        {
            PushMessage notification = new AngularPushNotification
            {
                Title = "New Weather Forecast",
                Body = $"Temp. (C): {temperatureC} | Temp. (F): {32 + (int)(temperatureC / 0.5556)}",
                Icon = "assets/icons/icon-96x96.png"
            }.ToPushMessage();

            foreach (Subscription subscription in _pushSubscriptionsService.get())
            {
                Lib.Net.Http.WebPush.PushSubscription pushSubscription = new PushSubscription();
                pushSubscription.Endpoint = subscription.Token;
                //string p = null;
                //subscription..TryGetValue("p256dh", out p);
                //string a = null;
                //subscription.Keys.TryGetValue("auth", out a);
                pushSubscription.Keys = new Dictionary<string,string>();
                pushSubscription.Keys.Add("p256dh", subscription.PublicKey);
                pushSubscription.Keys.Add("auth", subscription.PrivateKey);

                // fire-and-forget
                _pushClient.RequestPushMessageDeliveryAsync(pushSubscription, notification);
            }
        }
    }



}
